DOCK HIDE (XOS) - modul LSPosed untuk menghilangkan background dockbar
Target: com.transsion.launcher3

CARA BUILD (GitHub, tanpa PC):
1. Buat repo baru di GitHub, upload SEMUA isi folder ini
   (termasuk folder .github, app, xposed-stub, settings.gradle, build.gradle).
2. Tab Actions -> workflow "build" -> tunggu hijau.
3. Buka run-nya -> Artifacts -> DockFix-apk -> unduh, ekstrak, install APK.

PAKAI:
1. LSPosed -> Modul -> aktifkan "Dock Hide (XOS)".
2. Scope: com.transsion.launcher3 (sudah dicentang otomatis, cek saja).
3. Force stop launcher:  su -c "am force-stop com.transsion.launcher3"
4. Kalau dock masih ada, buka LSPosed -> Log -> cari baris "DockFix:" dan kirim ke saya.
