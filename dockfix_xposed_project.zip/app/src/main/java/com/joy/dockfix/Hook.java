package com.joy.dockfix;

import android.graphics.Canvas;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Menyembunyikan background dockbar di launcher XOS.
 * Target: SmoothRoundWidgetLayout yang menjadi anak langsung TrHotseat
 * (lihat dumpsys activity top: TrHotseat > SmoothRoundWidgetLayout 990x255, tanpa id).
 */
public class Hook implements IXposedHookLoadPackage {

    private static final String PKG = "com.transsion.launcher3";
    private static final String CHILD = "SmoothRoundWidgetLayout";
    private static final String PARENT = "TrHotseat";
    private static volatile boolean logged = false;

    static boolean isDockBg(Object o) {
        if (!(o instanceof View)) return false;
        View v = (View) o;
        if (!v.getClass().getName().endsWith(CHILD)) return false;
        ViewParent p = v.getParent();
        if (p == null || !p.getClass().getName().endsWith(PARENT)) return false;
        if (!logged) {
            logged = true;
            XposedBridge.log("DockFix: background dock ditemukan dan disembunyikan ("
                    + v.getClass().getName() + " di " + p.getClass().getName() + ")");
        }
        return true;
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (!PKG.equals(lp.packageName)) return;
        XposedBridge.log("DockFix: aktif di " + lp.packageName);

        try {
            // 1) lewati penggambaran view ini sama sekali
            XC_MethodHook skipDraw = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (isDockBg(param.thisObject)) param.setResult(null);
                }
            };
            XposedHelpers.findAndHookMethod(View.class, "draw", Canvas.class, skipDraw);
            XposedHelpers.findAndHookMethod(ViewGroup.class, "dispatchDraw", Canvas.class, skipDraw);

            // 2) paksa alpha 0, kalau launcher menggambar lewat jalur sendiri
            XC_MethodHook alpha0 = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (isDockBg(param.thisObject)) param.args[0] = 0f;
                }
            };
            XposedHelpers.findAndHookMethod(View.class, "setAlpha", float.class, alpha0);

            // 3) set awal begitu view menempel ke window
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (isDockBg(param.thisObject)) ((View) param.thisObject).setAlpha(0f);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("DockFix: gagal pasang hook: " + t);
        }
    }
}
